package ru.ifmo.clientapp;

import ru.ifmo.lib.SimpleMessage;
import ru.ifmo.lib.Connection;

import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    private String ip;
    private int port;
    private Scanner scanner;


    public Client(String ip, int port) {
        this.ip = ip;
        this.port = port;
        scanner = new Scanner(System.in);
    }

    public void start(){
        System.out.println("Введите имя");
        String userName = scanner.nextLine();
        String text;    // count    help
        while (true) { // img путь/к/файлу  ["img", "путь/к/файлу"]
            //System.out.println("Введите команду");
            text = scanner.nextLine();
            if ("exit".equals(text)) break;
            sendAndPrintMessage(SimpleMessage.getMessage(userName, text));

            /*if (text.equalsIgnoreCase(CommandsNames.HELP) ||
                text.equalsIgnoreCase(CommandsNames.COUNT)) {
                sendAndPrintMessage(SimpleMessage.getMessage(userName, text));
            } else if(text.contains(CommandsNames.IMG)) {
                String fileName = text.split(" ")[1];
                String commandName = text.split(" ")[0];
                ImgHandler handler = new ImgHandler(new File(fileName));
                ImgMessage imgMessage = null;
                try {
                    imgMessage = new ImgMessage(
                            userName, commandName, handler.readFromFile()
                    );
                    imgMessage.setExtension(handler.getExtension());
                    sendAndPrintMessage(imgMessage);
                } catch (IOException e) {
                    System.out.println("Не удалось прочитать файл");
                }
            } else {
                System.out.println("Такой команды не существует");
            }*/
        }
    }

    private void sendAndPrintMessage(SimpleMessage message){
        try (Connection connection = new Connection(new Socket(ip, port))){
            connection.sendMessage(message);

            SimpleMessage fromServer = connection.readMessage();
            System.out.println(fromServer);
        } catch (IOException e) {
            System.out.println("Ошибка отправки - получения сообщения");
        } catch (ClassNotFoundException e) {
            System.out.println("Ошибка чтения сообщения");
        } catch (Exception e) {
            System.out.println("Ошибка соединения");
        }
    }
}
