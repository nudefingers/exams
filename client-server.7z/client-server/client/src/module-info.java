module client {
    requires common;
}

// ru.ifmo.clientapp