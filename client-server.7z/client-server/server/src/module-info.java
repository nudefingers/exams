module server {
    requires common;
}
// ru.ifmo.serverapp