package ru.ifmo.serverapp;

import ru.ifmo.lib.Connection;
import ru.ifmo.lib.SimpleMessage;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;

public class ReadMessage implements Runnable{
    private ArrayBlockingQueue<SimpleMessage> messages;
    private Connection connection;
    private Socket newClient;
    private String client;

    public ReadMessage(ArrayBlockingQueue<SimpleMessage> messages, Socket newClient) {
        this.messages = messages;
        this.newClient = newClient;
    }

    public String getClient() {
        return client;
    }

    public Connection getConnection() {
        return connection;
    }

    @Override
    public void run() {
        try {
            while (true) {
                connection = new Connection(newClient);
                SimpleMessage message = connection.readMessage();
                client = message.getSender();
                System.out.println(message);
                messages.put(message);
            }
        } catch (IOException e) {
            System.out.println("Ошибка сервера");
        } catch (ClassNotFoundException e) {
            System.out.println("Ошибка чтения сообщения");
        } catch (InterruptedException e) {
            System.out.println("InterruptedException");
        }
    }
}
