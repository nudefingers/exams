package ru.ifmo.serverapp;

import ru.ifmo.lib.Connection;
import ru.ifmo.lib.SimpleMessage;

import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;

public class WriteMessage implements Runnable{
    private ArrayBlockingQueue<SimpleMessage> messages;
    private HashMap<String, Connection> clients;

    public WriteMessage(ArrayBlockingQueue<SimpleMessage> messages, HashMap<String, Connection> clients) {
        this.messages = Objects.requireNonNull(messages);
        this.clients = clients;
    }

    @Override
    public void run() {
        Connection connection;
        String sender;

        try {

            while (true) {

                for (SimpleMessage message : messages) {
                    for (Map.Entry<String, Connection> entry : clients.entrySet()) {
                        sender = entry.getKey();

                        if (sender != message.getSender()) {
                            connection = entry.getValue();
                            connection.sendMessage(message);
                        }
                    }

                    messages.take();

                }
            }
        } catch (IOException e) {
            System.out.println("Ошибка сервера");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
