package ru.ifmo.serverapp;

import ru.ifmo.lib.Connection;
import ru.ifmo.lib.SimpleMessage;
import ru.ifmo.lib.handlers.ImgHandler;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;

public class Server {
    private int port;
    private HashMap<String, Connection> clients;
    private Connection connection;
    private ArrayBlockingQueue<SimpleMessage> messages;

    public Server(int port) {
        this.port = port;
        clients = new HashMap<>();
        this.messages = new ArrayBlockingQueue<>(10, true);
    }

    public void start(){

        try (ServerSocket serverSocket = new ServerSocket(port)){
            System.out.println("Сервер запущен");

            while (true) {
                Socket newClient = serverSocket.accept();
                ReadMessage reader = new ReadMessage(messages, newClient);
                new Thread(reader).start();

                if (!clients.containsKey(reader.getClient()) && reader.getClient() != null) {
                    clients.put(reader.getClient(), reader.getConnection());
                }

                WriteMessage writer = new WriteMessage(messages, clients);
                new Thread(writer).start();
            }
        } catch (IOException e) {
            System.out.println("Ошибка сервера");
        } //catch (ClassNotFoundException e) {
            //System.out.println("Ошибка чтения сообщения");
        //}
    }

}
