module common {
    requires java.desktop;
    exports ru.ifmo.lib;
    exports ru.ifmo.lib.handlers;
}
